
<div class="mt-3">


	
<div class="card my-3" id="">
  <div class="card-header text-center">
   Withdraw Money
  </div>
  <div class="card-body">
  
    <div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1"><i class="bi bi-bank"></i></span>
  <input type="text" class="form-control" placeholder="UPI ID / Mobile Number" id="upi" aria-label="" aria-describedby="basic-addon1">
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1"><i class="bi bi-tablet"></i></span>
  <select class="form-select" id="upiapp">
<option>Paytm</option>
<option>Google Pay</option>
<option>PhonePe</option>
  </select>

</div>
    <div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1"><i class="bi bi-currency-rupee"></i></span>
  <input type="number" class="form-control" placeholder="Amount" id="wamount" aria-label="" aria-describedby="basic-addon1">
</div>
<div class="small text-success">Minimum Withdraw : ₹ <?=$this->db->get('system')->row()->minimum_withdraw?></div>
    <button href="#" class="btn w-100 btn-dark my-2" id="wmoney_btn" >WITHDRAW MONEY</button>
<div class="text-success mt-1 small"><b>Note:</b> <?=$this->db->get('messages')->row()->on_withdraw_money?></div>
  </div>
</div>


</div>

<div class="card" id="">
  <div class="card-header text-center">
   Withdraws History
  </div>
  <div class="card-body">

<?php
if(!$txns){
?>
<p class="text-center small text-secondary mt-3">No Withdraws Available</p>
<?php
}
foreach($txns as $txn){
    ?>
<div class="py-2 border-bottom d-flex justify-content-between">
<div>
<p class="m-0 small fw-bold"><?=strtoupper($txn->upi_app)?> : <?=$txn->upi_mobile?></p>
<p class="m-0 small">Req Id : <?=$txn->req_id?></p>
<p class="m-0" style="font-size:11px"><?=date('d M Y, h:i a',$txn->created_at)?></p>
</div>
<div class="mx-1">

</div>
<div class="d-flex justify-content-start gap-2 flex-column align-items-end">

<p class="text-success fw-bold m-0 text-nowrap">₹ <?=number_format($txn->amount)?></p>
  

<?php
if($txn->status==0){
?>
<span class="badge bg-danger p-1" style="font-size:10px"><i class="bi bi-emoji-frown"></i> Rejected</span>
<?php
}elseif($txn->status==1){
?>
<span class="badge bg-success p-1" style="font-size:10px"><i class="bi bi-check2"></i> Completed</span>
<?php
}else{
?>
<span class="badge bg-warning p-1 text-dark" style="font-size:10px"><i class="bi bi-clock-history"></i> In Process</span>
<?php
}
?>

</div>
</div>

    <?php
}
?>   


<!-- </div>
    <button href="#" class="btn w-100 btn-primary my-2" id="loadmore-btn" >SHOW MORE</button>

  </div> -->
</div>

</div>



 <?php
if($this->db->get('messages')->row()->on_dashboard_top_marque){
  ?>
<marquee class="alert-dark fw-bold  py-2">
 <i class="bi bi-megaphone"></i> <?=$this->db->get('messages')->row()->on_dashboard_top_marque?>
</marquee>
  <?php
}
?>
<div class="py-3 px-3 bg-white shadow">
    <?php
if($this->db->get('messages')->row()->on_dashboard_top){
  ?>
<div class="alert alert-danger small fw-bold">
 <?=$this->db->get('messages')->row()->on_dashboard_top?>
</div>
  <?php
}
?>
<style>
.gc:hover{
cursor:pointer;
opacity:0.7;
}
  </style>
<div class="d-flex justify-content-between">
<span class=" fs-4">Games</span>
<div>
 <a class="btn btn-sm btn-outline-dark" href="#" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom" aria-controls="offcanvasBottom">
     <i class="bi bi-info-circle"></i> Instructions
    </a>
</div>
</div>

<div class="d-flex flex-wrap col-12 mt-2">
<?php
foreach($games as $index=>$game){
  ?>

<div class="col-6 p-2 pb-2">
  <a href="<?=base_url('user/matches/'.$game->id)?>" class="showloading text-decoration-none text-dark gc">
  <div class=" text-center h-100">
 
<img src="<?=base_url('assets/images/'.($game->logo?$game->logo:'no-img.png'))?>" class="w-100" />
<p class="m-0 p-0 animate__animated animate__tada animate__infinite	infinite d-inline-block px-2 py-1"><i class="bi bi-dice-6"></i> <?=$game->game_name?></p>
</div>
</a>
</div>

  <?php
}
?>
</div>





   <div>
<div class="d-flex mt-3">
  <div>
  <img src="<?=base_url('assets/images/'.$this->db->get('system')->row()->brand_logo)?>" alt="" width="100"><br>
 
</div>
<div class="small px-2">
  <b><?=$this->db->get('system')->row()->brand_name?></b><br>
<?=$this->db->get('system')->row()->meta_desc?>
</div>
</div>
<div class="d-flex flex-wrap justify-content-center gap-2 text-secondary" style="opacity:0.8">


</div>
</div>





</div>


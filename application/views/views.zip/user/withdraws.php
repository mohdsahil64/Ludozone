
<div class="mt-3 mx-2 p-2">


	


<div class="card" id="">
  <div class="card-header text-center">
   Withdraws History
  </div>
  <div class="card-body">

<?php
if(!$txns){
?>
<p class="text-center small text-secondary mt-3">No Withdraws Available</p>
<?php
}
foreach($txns as $txn){
    ?>
<div class="py-2 border-bottom d-flex justify-content-between">
<div>
<p class="m-0 small fw-bold"><?=strtoupper($txn->upi_app)?> : <?=$txn->upi_mobile?></p>
<p class="m-0 small">Req Id : <?=$txn->req_id?></p>
<p class="m-0" style="font-size:11px"><?=date('d M Y, h:i a',$txn->created_at)?></p>
</div>
<div class="mx-1">

</div>
<div class="d-flex justify-content-start gap-2 flex-column align-items-end">

<p class="text-success fw-bold m-0 text-nowrap">₹ <?=number_format($txn->amount)?></p>
  

<?php
if($txn->status==0){
?>
<span class="badge bg-danger p-1" style="font-size:10px"><i class="bi bi-emoji-frown"></i> Rejected</span>
<?php
}elseif($txn->status==1){
?>
<span class="badge bg-success p-1" style="font-size:10px"><i class="bi bi-check2"></i> Completed</span>
<?php
}else{
?>
<span class="badge bg-warning p-1 text-dark" style="font-size:10px"><i class="bi bi-clock-history"></i> In Process</span>
<?php
}
?>

</div>
</div>

    <?php
}
?>   


<!-- </div>
    <button href="#" class="btn w-100 btn-primary my-2" id="loadmore-btn" >SHOW MORE</button>

  </div> -->
</div>

</div>
